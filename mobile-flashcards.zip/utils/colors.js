export const white = '#F5F5F5';
export const red = '#F44336';
export const orange = '#F57C00';
export const amber = '#FFCC80';
export const black = '#444';
export const brown = '#FFA726';